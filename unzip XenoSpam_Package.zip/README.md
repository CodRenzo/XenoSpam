
<p align="center">
  <img src="https://media.giphy.com/media/IwSG1QKOwDjQk/giphy.gif" width="120" />
  <h1 align="center">XenoSpam</h1>
  <p align="center"><strong>Telegram Spam Bot by CodRenzo</strong></p>
</p>

---

### 🚀 Features

- 🔁 Auto-spamming messages to groups or users
- 🧠 Smart delay to bypass anti-spam
- 🎯 Target multiple users or chats
- ⚙️ Easy customization and setup
- 💻 Hostable on your own server/VPS

---

### 📦 Installation & Hosting Tutorial

> Add your detailed tutorial here (setup steps, requirements, etc.)

```bash
# Clone the repo
git clone https://github.com/CodRenzo/XenoSpam.git

# Install dependencies
pip install -r requirements.txt

# Run the bot
python xenospam.py
```

---

### 🧠 Credits

- Made by **CodRenzo**
- 📬 Telegram: [@CodRenzo](https://t.me/CodRenzo)
- 🧑‍💻 GitHub: [@CodRenzo](https://github.com/CodRenzo)
- 📢 Channel: [RavenDev](https://t.me/RavenDev)

---

### 📄 License

This project is licensed under a custom **Non-Commercial License**. You may freely use, modify, and share it **for non-commercial purposes**.

> Commercial use is **strictly prohibited** without explicit permission from CodRenzo.
